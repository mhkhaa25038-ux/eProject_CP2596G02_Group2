<?php
$pageTitle = 'Sửa rạp / chi nhánh';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();
$id = (int) get('id');
$error = '';

$stmt = $conn->prepare("SELECT * FROM locations WHERE location_id = ? LIMIT 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$location = $result->fetch_assoc();
$stmt->close();

if (!$location) {
    set_flash_message('error', 'Không tìm thấy rạp / chi nhánh.');
    redirect('admin/locations/index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim(post('name'));
    $address = trim(post('address'));
    $city = trim(post('city'));
    $phone = trim(post('phone'));
    $status = trim(post('status')) ?: 'active';

    if ($name === '' || $address === '' || $city === '') {
        $error = 'Vui lòng nhập đầy đủ tên rạp, địa chỉ và thành phố.';
    } else {
        $phone = $phone !== '' ? $phone : null;

        $sql = "UPDATE locations SET name = ?, address = ?, city = ?, phone = ?, status = ? WHERE location_id = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $error = 'Lỗi prepare: ' . $conn->error;
        } else {
            $stmt->bind_param('sssssi', $name, $address, $city, $phone, $status, $id);

            if ($stmt->execute()) {
                $stmt->close();
                set_flash_message('success', 'Cập nhật rạp / chi nhánh thành công.');
                redirect('admin/locations/index.php');
            } else {
                $error = 'Không thể cập nhật rạp / chi nhánh: ' . $stmt->error;
            }

            $stmt->close();
        }
    }
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Form sửa rạp / chi nhánh</h2>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/locations/index.php">Quay lại</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="admin-flash"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="admin-form-grid">
            <div class="admin-form-group">
                <label class="admin-label">Tên rạp / chi nhánh</label>
                <input class="admin-input" type="text" name="name" value="<?= e(old('name', $location['name'])) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Thành phố</label>
                <input class="admin-input" type="text" name="city" value="<?= e(old('city', $location['city'])) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Số điện thoại</label>
                <input class="admin-input" type="text" name="phone" value="<?= e(old('phone', $location['phone'] ?? '')) ?>">
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Trạng thái</label>
                <?php $currentStatus = old('status', $location['status']); ?>
                <select class="admin-select" name="status">
                    <option value="active" <?= $currentStatus === 'active' ? 'selected' : '' ?>>active</option>
                    <option value="inactive" <?= $currentStatus === 'inactive' ? 'selected' : '' ?>>inactive</option>
                </select>
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Địa chỉ</label>
                <input class="admin-input" type="text" name="address" value="<?= e(old('address', $location['address'])) ?>" required>
            </div>
        </div>

        <button class="admin-btn" type="submit">Cập nhật rạp / chi nhánh</button>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/admin_layout_end.php'; ?>