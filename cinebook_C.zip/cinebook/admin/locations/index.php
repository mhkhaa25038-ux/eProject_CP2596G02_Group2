<?php
$pageTitle = 'Quản lý rạp / chi nhánh';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();

$keyword = trim(get('keyword'));
$status = trim(get('status'));
$city = trim(get('city'));

$where = [];
$params = [];
$types = '';

if ($keyword !== '') {
    $where[] = "(name LIKE ? OR address LIKE ? OR phone LIKE ?)";
    $kw = '%' . $keyword . '%';
    $params[] = $kw;
    $params[] = $kw;
    $params[] = $kw;
    $types .= 'sss';
}

if ($city !== '') {
    $where[] = "city LIKE ?";
    $params[] = '%' . $city . '%';
    $types .= 's';
}

if ($status !== '') {
    $where[] = "status = ?";
    $params[] = $status;
    $types .= 's';
}

$whereSql = '';
if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

$sql = "
    SELECT
        l.location_id,
        l.name,
        l.address,
        l.city,
        l.phone,
        l.status,
        COUNT(r.room_id) AS room_count
    FROM locations l
    LEFT JOIN rooms r ON l.location_id = r.location_id
    $whereSql
    GROUP BY l.location_id, l.name, l.address, l.city, l.phone, l.status
    ORDER BY l.name ASC
";

$stmt = $conn->prepare($sql);
$result = false;

if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Danh sách rạp / chi nhánh</h2>
        <a class="admin-btn" href="<?= BASE_URL ?>admin/locations/create.php">+ Thêm rạp / chi nhánh</a>
    </div>

    <div class="admin-filter-bar">
        <form method="GET" action="">
            <input class="admin-input" type="text" name="keyword" placeholder="Tìm tên rạp / địa chỉ / số điện thoại..." value="<?= e($keyword) ?>">
            <input class="admin-input" type="text" name="city" placeholder="Thành phố..." value="<?= e($city) ?>">

            <select class="admin-select" name="status">
                <option value="">-- Tất cả trạng thái --</option>
                <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>active</option>
                <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>inactive</option>
            </select>

            <button class="admin-btn" type="submit">Tìm kiếm</button>
            <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/locations/index.php">Reset</a>
        </form>
    </div>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên rạp</th>
                    <th>Địa chỉ</th>
                    <th>Thành phố</th>
                    <th>SĐT</th>
                    <th>Số phòng</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($location = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= (int) $location['location_id'] ?></td>
                        <td><?= e($location['name']) ?></td>
                        <td><?= e($location['address']) ?></td>
                        <td><?= e($location['city']) ?></td>
                        <td><?= e($location['phone'] ?: 'N/A') ?></td>
                        <td><?= (int) $location['room_count'] ?></td>
                        <td>
                            <span class="admin-badge <?= $location['status'] === 'active' ? 'active' : 'coming' ?>">
                                <?= e($location['status']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="admin-actions">
                                <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/locations/edit.php?id=<?= (int) $location['location_id'] ?>">Sửa</a>
                                <a class="admin-btn-danger" href="<?= BASE_URL ?>admin/locations/delete.php?id=<?= (int) $location['location_id'] ?>" onclick="return confirm('Xóa rạp / chi nhánh này?')">Xóa</a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">
                        <div class="admin-empty">Không tìm thấy rạp / chi nhánh phù hợp.</div>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
if ($stmt) {
    $stmt->close();
}
require_once __DIR__ . '/../../includes/admin_layout_end.php';
?>