<?php
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

$conn = db_connect();
$id = (int) get('id');

if ($id <= 0) {
    set_flash_message('error', 'ID rạp / chi nhánh không hợp lệ.');
    redirect('admin/locations/index.php');
}

$checkStmt = $conn->prepare("SELECT COUNT(*) AS total FROM rooms WHERE location_id = ?");
$checkStmt->bind_param('i', $id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();
$checkRow = $checkResult->fetch_assoc();
$checkStmt->close();

if ((int) ($checkRow['total'] ?? 0) > 0) {
    set_flash_message('error', 'Rạp / chi nhánh này đang có phòng chiếu. Không nên xóa trực tiếp, hãy chuyển trạng thái sang inactive.');
    redirect('admin/locations/index.php');
}

$stmt = $conn->prepare("DELETE FROM locations WHERE location_id = ?");

if (!$stmt) {
    set_flash_message('error', 'Không thể chuẩn bị câu lệnh xóa.');
    redirect('admin/locations/index.php');
}

$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    set_flash_message('success', 'Xóa rạp / chi nhánh thành công.');
} else {
    set_flash_message('error', 'Không thể xóa rạp / chi nhánh: ' . $stmt->error);
}

$stmt->close();
redirect('admin/locations/index.php');