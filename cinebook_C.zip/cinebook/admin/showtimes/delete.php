<?php
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

$conn = db_connect();
$id = (int) get('id');

if ($id <= 0) {
    set_flash_message('error', 'ID suất chiếu không hợp lệ.');
    redirect('admin/showtimes/index.php');
}

$bookingCount = count_showtime_bookings($conn, $id);

if ($bookingCount > 0) {
    set_flash_message('error', 'Suất chiếu này đã có booking. Không nên xóa, hãy chuyển trạng thái sang cancelled.');
    redirect('admin/showtimes/index.php');
}

$stmt = $conn->prepare('DELETE FROM showtimes WHERE show_id = ?');

if (!$stmt) {
    set_flash_message('error', 'Không thể chuẩn bị câu lệnh xóa.');
    redirect('admin/showtimes/index.php');
}

$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    set_flash_message('success', 'Xóa suất chiếu thành công.');
} else {
    set_flash_message('error', 'Không thể xóa suất chiếu: ' . $stmt->error);
}

$stmt->close();
redirect('admin/showtimes/index.php');