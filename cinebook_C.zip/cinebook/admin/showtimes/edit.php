<?php
$pageTitle = 'Sửa suất chiếu';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();
$id = (int) get('id');
$error = '';

$detailSql = '
    SELECT s.*, m.title AS movie_title, r.room_name, l.name AS location_name
    FROM showtimes s
    INNER JOIN movies m ON s.movie_id = m.movie_id
    INNER JOIN rooms r ON s.room_id = r.room_id
    INNER JOIN locations l ON r.location_id = l.location_id
    WHERE s.show_id = ?
    LIMIT 1
';
$detailStmt = $conn->prepare($detailSql);
$detailStmt->bind_param('i', $id);
$detailStmt->execute();
$detailResult = $detailStmt->get_result();
$showtime = $detailResult->fetch_assoc();
$detailStmt->close();

if (!$showtime) {
    set_flash_message('error', 'Không tìm thấy suất chiếu.');
    redirect('admin/showtimes/index.php');
}

$movies = $conn->query("SELECT movie_id, title, status FROM movies ORDER BY status ASC, title ASC");
$rooms = $conn->query("
    SELECT r.room_id, r.room_name, l.name AS location_name, r.status
    FROM rooms r
    INNER JOIN locations l ON r.location_id = l.location_id
    ORDER BY l.name ASC, r.room_name ASC
");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movieId = (int) post('movie_id');
    $roomId = (int) post('room_id');
    $startAt = trim(post('start_at'));
    $endAt = trim(post('end_at'));
    $basePrice = (float) post('base_price');
    $screenFormat = trim(post('screen_format')) ?: '2D';
    $subtitleType = trim(post('subtitle_type'));
    $status = trim(post('status')) ?: 'scheduled';

    if ($movieId <= 0 || $roomId <= 0 || $startAt === '' || $endAt === '' || $basePrice <= 0) {
        $error = 'Vui lòng nhập đầy đủ phim, phòng, thời gian và giá cơ bản hợp lệ.';
    } elseif (strtotime($endAt) <= strtotime($startAt)) {
        $error = 'Giờ kết thúc phải lớn hơn giờ bắt đầu.';
    } else {
        $overlapSql = "
            SELECT COUNT(*) AS total
            FROM showtimes
            WHERE room_id = ?
              AND show_id <> ?
              AND status = 'scheduled'
              AND NOT (end_at <= ? OR start_at >= ?)
        ";
        $overlapStmt = $conn->prepare($overlapSql);
        $overlapStmt->bind_param('iiss', $roomId, $id, $startAt, $endAt);
        $overlapStmt->execute();
        $overlapResult = $overlapStmt->get_result();
        $overlapRow = $overlapResult->fetch_assoc();
        $overlapStmt->close();

        if ((int) ($overlapRow['total'] ?? 0) > 0) {
            $error = 'Phòng chiếu đã có suất khác trùng thời gian. Vui lòng chọn khung giờ khác.';
        } else {
            $bookingCount = count_showtime_bookings($conn, $id);
            $roomChanged = (int) $showtime['room_id'] !== $roomId;

            if ($roomChanged && $bookingCount > 0) {
                $error = 'Suất chiếu này đã có booking, không thể đổi phòng chiếu. Chỉ nên cập nhật thời gian hoặc trạng thái.';
            } else {
                $subtitleType = $subtitleType !== '' ? $subtitleType : null;

                try {
                    $conn->begin_transaction();

                    $sql = '
                        UPDATE showtimes
                        SET movie_id = ?, room_id = ?, start_at = ?, end_at = ?, base_price = ?, screen_format = ?, subtitle_type = ?, status = ?
                        WHERE show_id = ?
                    ';
                    $stmt = $conn->prepare($sql);

                    if (!$stmt) {
                        throw new Exception('Lỗi prepare showtime.');
                    }

                    $stmt->bind_param('iissdsssi', $movieId, $roomId, $startAt, $endAt, $basePrice, $screenFormat, $subtitleType, $status, $id);

                    if (!$stmt->execute()) {
                        throw new Exception('Không thể cập nhật suất chiếu.');
                    }
                    $stmt->close();

                    if (!sync_show_seats($conn, $id, $roomId, $basePrice, $roomChanged && $bookingCount === 0)) {
                        throw new Exception('Không thể đồng bộ ghế theo suất chiếu.');
                    }

                    $conn->commit();
                    set_flash_message('success', 'Cập nhật suất chiếu thành công.');
                    redirect('admin/showtimes/index.php');
                } catch (Throwable $e) {
                    $conn->rollback();
                    $error = $e->getMessage();
                }
            }
        }
    }
}

$startValue = !empty($showtime['start_at']) ? date('Y-m-d\\TH:i', strtotime($showtime['start_at'])) : '';
$endValue = !empty($showtime['end_at']) ? date('Y-m-d\\TH:i', strtotime($showtime['end_at'])) : '';
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Form sửa suất chiếu</h2>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/showtimes/index.php">Quay lại</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="admin-flash"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="admin-form-grid">
            <div class="admin-form-group">
                <label class="admin-label">Phim</label>
                <select class="admin-select" name="movie_id" required>
                    <option value="">-- Chọn phim --</option>
                    <?php if ($movies && $movies->num_rows > 0): ?>
                        <?php while ($movie = $movies->fetch_assoc()): ?>
                            <option value="<?= (int) $movie['movie_id'] ?>" <?= (int) old('movie_id', (string) $showtime['movie_id']) === (int) $movie['movie_id'] ? 'selected' : '' ?>>
                                <?= e($movie['title']) ?> (<?= e($movie['status']) ?>)
                            </option>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Phòng chiếu</label>
                <select class="admin-select" name="room_id" required>
                    <option value="">-- Chọn phòng --</option>
                    <?php if ($rooms && $rooms->num_rows > 0): ?>
                        <?php while ($room = $rooms->fetch_assoc()): ?>
                            <option value="<?= (int) $room['room_id'] ?>" <?= (int) old('room_id', (string) $showtime['room_id']) === (int) $room['room_id'] ? 'selected' : '' ?>>
                                <?= e($room['location_name'] . ' - ' . $room['room_name'] . ' (' . $room['status'] . ')') ?>
                            </option>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Bắt đầu</label>
                <input class="admin-input" type="datetime-local" name="start_at" value="<?= e(old('start_at', $startValue)) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Kết thúc</label>
                <input class="admin-input" type="datetime-local" name="end_at" value="<?= e(old('end_at', $endValue)) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Giá cơ bản</label>
                <input class="admin-input" type="number" name="base_price" min="1000" step="1000" value="<?= e(old('base_price', $showtime['base_price'])) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Trạng thái</label>
                <?php $currentStatus = old('status', $showtime['status']); ?>
                <select class="admin-select" name="status">
                    <option value="scheduled" <?= $currentStatus === 'scheduled' ? 'selected' : '' ?>>scheduled</option>
                    <option value="completed" <?= $currentStatus === 'completed' ? 'selected' : '' ?>>completed</option>
                    <option value="cancelled" <?= $currentStatus === 'cancelled' ? 'selected' : '' ?>>cancelled</option>
                </select>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Định dạng</label>
                <?php $currentFormat = old('screen_format', $showtime['screen_format'] ?: '2D'); ?>
                <select class="admin-select" name="screen_format">
                    <option value="2D" <?= $currentFormat === '2D' ? 'selected' : '' ?>>2D</option>
                    <option value="3D" <?= $currentFormat === '3D' ? 'selected' : '' ?>>3D</option>
                    <option value="IMAX" <?= $currentFormat === 'IMAX' ? 'selected' : '' ?>>IMAX</option>
                </select>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Phụ đề / lồng tiếng</label>
                <input class="admin-input" type="text" name="subtitle_type" placeholder="Phụ đề Việt, Lồng tiếng Việt..." value="<?= e(old('subtitle_type', $showtime['subtitle_type'] ?? '')) ?>">
            </div>
        </div>

        <button class="admin-btn" type="submit">Cập nhật suất chiếu</button>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/admin_layout_end.php'; ?>