<?php
$pageTitle = 'Thêm combo';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim(post('name'));
    $description = trim(post('description'));
    $price = (float) post('price');
    $image = trim(post('image'));
    $status = trim(post('status')) ?: 'active';

    if ($name === '' || $price <= 0) {
        $error = 'Vui lòng nhập tên combo và giá hợp lệ.';
    } else {
        $description = $description !== '' ? $description : null;
        $image = $image !== '' ? $image : null;

        $sql = 'INSERT INTO combo_products (name, description, price, image, status) VALUES (?, ?, ?, ?, ?)';
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $error = 'Lỗi prepare: ' . $conn->error;
        } else {
            $stmt->bind_param('ssdss', $name, $description, $price, $image, $status);

            if ($stmt->execute()) {
                $stmt->close();
                set_flash_message('success', 'Thêm combo thành công.');
                redirect('admin/combos/index.php');
            } else {
                $error = 'Không thể thêm combo: ' . $stmt->error;
            }

            $stmt->close();
        }
    }
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Form thêm combo</h2>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/combos/index.php">Quay lại</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="admin-flash"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="admin-form-grid">
            <div class="admin-form-group full">
                <label class="admin-label">Tên combo</label>
                <input class="admin-input" type="text" name="name" value="<?= e(old('name')) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Giá</label>
                <input class="admin-input" type="number" name="price" min="1000" step="1000" value="<?= e(old('price')) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Trạng thái</label>
                <select class="admin-select" name="status">
                    <option value="active" <?= old('status', 'active') === 'active' ? 'selected' : '' ?>>active</option>
                    <option value="inactive" <?= old('status') === 'inactive' ? 'selected' : '' ?>>inactive</option>
                </select>
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Ảnh combo (URL)</label>
                <input class="admin-input" type="text" name="image" value="<?= e(old('image')) ?>">
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Mô tả</label>
                <textarea class="admin-textarea" name="description"><?= e(old('description')) ?></textarea>
            </div>
        </div>

        <button class="admin-btn" type="submit">Lưu combo</button>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/admin_layout_end.php'; ?>