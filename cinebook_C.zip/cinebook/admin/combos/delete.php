<?php
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

$conn = db_connect();
$id = (int) get('id');

if ($id <= 0) {
    set_flash_message('error', 'ID combo không hợp lệ.');
    redirect('admin/combos/index.php');
}

$stmt = $conn->prepare('DELETE FROM combo_products WHERE combo_id = ?');

if (!$stmt) {
    set_flash_message('error', 'Không thể chuẩn bị câu lệnh xóa.');
    redirect('admin/combos/index.php');
}

$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    set_flash_message('success', 'Xóa combo thành công.');
} else {
    set_flash_message('error', 'Không thể xóa combo. Có thể combo này đã được gắn vào đơn đặt vé.');
}

$stmt->close();
redirect('admin/combos/index.php');