<?php
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

$conn = db_connect();
$id = (int) get('id');

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM seat_categories WHERE category_id = ?");
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        set_flash_message('success', 'Xóa loại ghế thành công.');
    } else {
        set_flash_message('error', 'Không thể xóa loại ghế. Có thể đang được sử dụng trong bảng ghế.');
    }

    $stmt->close();
}

redirect('admin/seat_categories/index.php');