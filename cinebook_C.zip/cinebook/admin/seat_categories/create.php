<?php
$pageTitle = 'Thêm loại ghế';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim(post('name'));
    $priceMultiplier = (float) post('price_multiplier');

    if ($name === '') {
        $error = 'Vui lòng nhập tên loại ghế.';
    } elseif ($priceMultiplier <= 0) {
        $error = 'Hệ số giá phải lớn hơn 0.';
    } else {
        $sql = "INSERT INTO seat_categories (name, price_multiplier) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $error = 'Lỗi prepare: ' . $conn->error;
        } else {
            $stmt->bind_param('sd', $name, $priceMultiplier);

            if ($stmt->execute()) {
                $stmt->close();
                set_flash_message('success', 'Thêm loại ghế thành công.');
                redirect('admin/seat_categories/index.php');
            } else {
                $error = 'Lỗi thêm loại ghế: ' . $stmt->error;
            }

            $stmt->close();
        }
    }
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Form thêm loại ghế</h2>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/seat_categories/index.php">Quay lại</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="admin-flash"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="admin-form-grid">
            <div class="admin-form-group">
                <label class="admin-label">Tên loại ghế</label>
                <input class="admin-input" type="text" name="name" placeholder="Standard / VIP / Couple..." required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Hệ số giá</label>
                <input class="admin-input" type="number" name="price_multiplier" min="0.01" step="0.01" placeholder="1.00" required>
            </div>
        </div>

        <button class="admin-btn" type="submit">Lưu loại ghế</button>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/admin_layout_end.php'; ?>