<?php
$pageTitle = 'Quản lý loại ghế';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();

$keyword = trim(get('keyword'));
$priceMultiplier = trim(get('price_multiplier'));

$where = [];
$params = [];
$types = '';

if ($keyword !== '') {
    $where[] = "name LIKE ?";
    $params[] = '%' . $keyword . '%';
    $types .= 's';
}

if ($priceMultiplier !== '' && is_numeric($priceMultiplier)) {
    $where[] = "price_multiplier = ?";
    $params[] = (float) $priceMultiplier;
    $types .= 'd';
}

$whereSql = '';
if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

$sql = "
    SELECT category_id, name, price_multiplier
    FROM seat_categories
    $whereSql
    ORDER BY category_id ASC
";

$stmt = $conn->prepare($sql);
$result = false;

if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Danh sách loại ghế</h2>
        <a class="admin-btn" href="<?= BASE_URL ?>admin/seat_categories/create.php">+ Thêm loại ghế</a>
    </div>

    <div class="admin-filter-bar">
        <form method="GET" action="">
            <input class="admin-input" type="text" name="keyword" placeholder="Tìm tên loại ghế..." value="<?= e($keyword) ?>">
            <input class="admin-input" type="number" step="0.01" name="price_multiplier" placeholder="Hệ số giá..." value="<?= e($priceMultiplier) ?>">

            <button class="admin-btn" type="submit">Tìm kiếm</button>
            <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/seat_categories/index.php">Reset</a>
        </form>
    </div>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên loại ghế</th>
                    <th>Hệ số giá</th>
                    <th>Giải thích</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($category = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= (int) $category['category_id'] ?></td>
                        <td><?= e($category['name']) ?></td>
                        <td><?= number_format((float) $category['price_multiplier'], 2) ?></td>
                        <td>
                            <?php
                            $multiplier = (float) $category['price_multiplier'];
                            if ($multiplier == 1.00) {
                                echo 'Giá chuẩn';
                            } elseif ($multiplier > 1.00) {
                                echo 'Cao hơn giá chuẩn';
                            } else {
                                echo 'Thấp hơn giá chuẩn';
                            }
                            ?>
                        </td>
                        <td>
                            <div class="admin-actions">
                                <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/seat_categories/edit.php?id=<?= (int) $category['category_id'] ?>">Sửa</a>
                                <a class="admin-btn-danger" href="<?= BASE_URL ?>admin/seat_categories/delete.php?id=<?= (int) $category['category_id'] ?>" onclick="return confirm('Xóa loại ghế này?')">Xóa</a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5"><div class="admin-empty">Không tìm thấy loại ghế phù hợp.</div></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
if ($stmt) {
    $stmt->close();
}
require_once __DIR__ . '/../../includes/admin_layout_end.php';
?>