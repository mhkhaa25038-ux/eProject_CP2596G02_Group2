<?php
$pageTitle = 'Dashboard Admin';
require_once __DIR__ . '/../includes/admin_layout_start.php';

$conn = db_connect();

$totalMovies = 0;
$totalRooms = 0;
$totalSeats = 0;
$totalNowShowing = 0;
$totalComingSoon = 0;
$totalLocations = 0;
$totalShowtimes = 0;
$totalEvents = 0;
$totalCombos = 0;

$result = $conn->query("SELECT COUNT(*) AS total FROM movies");
if ($result) {
    $row = $result->fetch_assoc();
    $totalMovies = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM rooms");
if ($result) {
    $row = $result->fetch_assoc();
    $totalRooms = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM seats");
if ($result) {
    $row = $result->fetch_assoc();
    $totalSeats = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM movies WHERE status = 'now_showing'");
if ($result) {
    $row = $result->fetch_assoc();
    $totalNowShowing = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM movies WHERE status = 'coming_soon'");
if ($result) {
    $row = $result->fetch_assoc();
    $totalComingSoon = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM locations");
if ($result) {
    $row = $result->fetch_assoc();
    $totalLocations = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM showtimes");
if ($result) {
    $row = $result->fetch_assoc();
    $totalShowtimes = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM events");
if ($result) {
    $row = $result->fetch_assoc();
    $totalEvents = (int) $row['total'];
}

$result = $conn->query("SELECT COUNT(*) AS total FROM combo_products");
if ($result) {
    $row = $result->fetch_assoc();
    $totalCombos = (int) $row['total'];
}

$latestMovies = $conn->query("
    SELECT movie_id, title, language, duration_min, status, created_at
    FROM movies
    ORDER BY created_at DESC
    LIMIT 5
");

$latestShowtimes = $conn->query("
    SELECT s.show_id, s.start_at, s.status, m.title AS movie_title, r.room_name, l.name AS location_name
    FROM showtimes s
    INNER JOIN movies m ON s.movie_id = m.movie_id
    INNER JOIN rooms r ON s.room_id = r.room_id
    INNER JOIN locations l ON r.location_id = l.location_id
    ORDER BY s.created_at DESC
    LIMIT 5
");
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Tổng quan hệ thống</h2>
    </div>

    <div style="display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:16px;">
        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng phim</h3>
            <p style="font-size:34px; font-weight:800;"><?= $totalMovies ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng suất chiếu</h3>
            <p style="font-size:34px; font-weight:800;"><?= $totalShowtimes ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng combo</h3>
            <p style="font-size:34px; font-weight:800;"><?= $totalCombos ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng sự kiện</h3>
            <p style="font-size:34px; font-weight:800; color:#93c5fd;"><?= $totalEvents ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Phim đang chiếu</h3>
            <p style="font-size:34px; font-weight:800; color:#86efac;"><?= $totalNowShowing ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Phim sắp chiếu</h3>
            <p style="font-size:34px; font-weight:800; color:#fde68a;"><?= $totalComingSoon ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng phòng</h3>
            <p style="font-size:34px; font-weight:800;"><?= $totalRooms ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng ghế</h3>
            <p style="font-size:34px; font-weight:800;"><?= $totalSeats ?></p>
        </div>

        <div class="admin-card" style="margin-bottom:0;">
            <h3 style="font-size:16px; color:#94a3b8; margin-bottom:8px;">Tổng rạp / chi nhánh</h3>
            <p style="font-size:34px; font-weight:800; color:#93c5fd;"><?= $totalLocations ?></p>
        </div>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Truy cập nhanh</h2>
    </div>

    <div class="admin-actions">
        <a class="admin-btn" href="<?= BASE_URL ?>admin/movies/index.php">Quản lý phim</a>
        <a class="admin-btn" href="<?= BASE_URL ?>admin/showtimes/index.php">Manage Showtimes</a>
        <a class="admin-btn" href="<?= BASE_URL ?>admin/events/index.php">Manage Events</a>
        <a class="admin-btn" href="<?= BASE_URL ?>admin/combos/index.php">Manage Combos</a>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/rooms/index.php">Quản lý phòng</a>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/seats/index.php">Quản lý ghế</a>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>">Trang user</a>
    </div>
</div>


    


<?php require_once __DIR__ . '/../includes/admin_layout_end.php'; ?>