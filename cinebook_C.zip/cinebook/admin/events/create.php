<?php
$pageTitle = 'Thêm sự kiện';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim(post('title'));
    $description = trim(post('description'));
    $startAt = trim(post('start_at'));
    $endAt = trim(post('end_at'));
    $image = trim(post('image'));
    $status = trim(post('status')) ?: 'active';

    if ($title === '' || $startAt === '' || $endAt === '') {
        $error = 'Vui lòng nhập tiêu đề, thời gian bắt đầu và thời gian kết thúc.';
    } elseif (strtotime($endAt) <= strtotime($startAt)) {
        $error = 'Thời gian kết thúc phải lớn hơn thời gian bắt đầu.';
    } else {
        $description = $description !== '' ? $description : null;
        $image = $image !== '' ? $image : null;

        $sql = 'INSERT INTO events (title, description, start_at, end_at, image, status) VALUES (?, ?, ?, ?, ?, ?)';
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $error = 'Lỗi prepare: ' . $conn->error;
        } else {
            $stmt->bind_param('ssssss', $title, $description, $startAt, $endAt, $image, $status);

            if ($stmt->execute()) {
                $stmt->close();
                set_flash_message('success', 'Thêm sự kiện thành công.');
                redirect('admin/events/index.php');
            } else {
                $error = 'Không thể thêm sự kiện: ' . $stmt->error;
            }

            $stmt->close();
        }
    }
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Form thêm sự kiện</h2>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/events/index.php">Quay lại</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="admin-flash"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="admin-form-grid">
            <div class="admin-form-group full">
                <label class="admin-label">Tiêu đề sự kiện</label>
                <input class="admin-input" type="text" name="title" value="<?= e(old('title')) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Bắt đầu</label>
                <input class="admin-input" type="datetime-local" name="start_at" value="<?= e(old('start_at')) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Kết thúc</label>
                <input class="admin-input" type="datetime-local" name="end_at" value="<?= e(old('end_at')) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Trạng thái</label>
                <select class="admin-select" name="status">
                    <option value="active" <?= old('status', 'active') === 'active' ? 'selected' : '' ?>>active</option>
                    <option value="inactive" <?= old('status') === 'inactive' ? 'selected' : '' ?>>inactive</option>
                </select>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Ảnh sự kiện (URL)</label>
                <input class="admin-input" type="text" name="image" value="<?= e(old('image')) ?>">
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Mô tả</label>
                <textarea class="admin-textarea" name="description"><?= e(old('description')) ?></textarea>
            </div>
        </div>

        <button class="admin-btn" type="submit">Lưu sự kiện</button>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/admin_layout_end.php'; ?>