<?php
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

$conn = db_connect();
$id = (int) get('id');

if ($id <= 0) {
    set_flash_message('error', 'ID sự kiện không hợp lệ.');
    redirect('admin/events/index.php');
}

$stmt = $conn->prepare('DELETE FROM events WHERE event_id = ?');

if (!$stmt) {
    set_flash_message('error', 'Không thể chuẩn bị câu lệnh xóa.');
    redirect('admin/events/index.php');
}

$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    set_flash_message('success', 'Xóa sự kiện thành công.');
} else {
    set_flash_message('error', 'Không thể xóa sự kiện: ' . $stmt->error);
}

$stmt->close();
redirect('admin/events/index.php');