<?php
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

$conn = db_connect();
$id = (int) get('id');

if ($id <= 0) {
    set_flash_message('error', 'ID thể loại không hợp lệ.');
    redirect('admin/genres/index.php');
}

$stmt = $conn->prepare("DELETE FROM genres WHERE genre_id = ?");

if (!$stmt) {
    set_flash_message('error', 'Không thể chuẩn bị câu lệnh xóa.');
    redirect('admin/genres/index.php');
}

$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    set_flash_message('success', 'Xóa thể loại thành công.');
} else {
    set_flash_message('error', 'Không thể xóa thể loại: ' . $stmt->error);
}

$stmt->close();
redirect('admin/genres/index.php');