<?php
$pageTitle = 'Quản lý phim';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();

$keyword = trim((string) get('keyword'));
$status = trim((string) get('status'));
$language = trim((string) get('language'));

$where = [];
$params = [];
$types = '';

if ($keyword !== '') {
    $where[] = "(m.title LIKE ? OR m.synopsis LIKE ?)";
    $kw = '%' . $keyword . '%';
    $params[] = $kw;
    $params[] = $kw;
    $types .= 'ss';
}

if ($status !== '') {
    $where[] = "m.status = ?";
    $params[] = $status;
    $types .= 's';
}

if ($language !== '') {
    $where[] = "m.language LIKE ?";
    $params[] = '%' . $language . '%';
    $types .= 's';
}

$whereSql = '';
if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

$sql = "
    SELECT
        m.movie_id,
        m.title,
        m.language,
        m.duration_min,
        m.poster_url,
        m.status,
        m.age_rating,
        m.release_date,
        GROUP_CONCAT(DISTINCT g.name ORDER BY g.name SEPARATOR ', ') AS genres
    FROM movies m
    LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
    LEFT JOIN genres g ON mg.genre_id = g.genre_id
    $whereSql
    GROUP BY
        m.movie_id,
        m.title,
        m.language,
        m.duration_min,
        m.poster_url,
        m.status,
        m.age_rating,
        m.release_date,
        m.created_at
    ORDER BY m.created_at DESC
";

$stmt = $conn->prepare($sql);
$result = false;

if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Danh sách phim</h2>
        <a class="admin-btn" href="<?= BASE_URL ?>admin/movies/create.php">+ Thêm phim</a>
    </div>

    <div class="admin-filter-bar">
        <form method="GET" action="">
            <input class="admin-input" type="text" name="keyword" placeholder="Tìm tên phim / mô tả..." value="<?= e($keyword) ?>">
            <input class="admin-input" type="text" name="language" placeholder="Ngôn ngữ..." value="<?= e($language) ?>">

            <select class="admin-select" name="status">
                <option value="">-- Tất cả trạng thái --</option>
                <option value="now_showing" <?= $status === 'now_showing' ? 'selected' : '' ?>>now_showing</option>
                <option value="coming_soon" <?= $status === 'coming_soon' ? 'selected' : '' ?>>coming_soon</option>
                <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>inactive</option>
            </select>

            <button class="admin-btn" type="submit">Tìm kiếm</button>
            <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/movies/index.php">Reset</a>
        </form>
    </div>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Poster</th>
                    <th>Tên phim</th>
                    <th>Thể loại</th>
                    <th>Ngôn ngữ</th>
                    <th>Thời lượng</th>
                    <th>Độ tuổi</th>
                    <th>Khởi chiếu</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($movie = $result->fetch_assoc()): ?>
                    <?php
                    $badgeClass = 'coming';
                    if ($movie['status'] === 'now_showing') {
                        $badgeClass = 'showing';
                    } elseif ($movie['status'] === 'inactive') {
                        $badgeClass = 'coming';
                    }
                    ?>
                    <tr>
                        <td>
                            <img class="admin-thumb" src="<?= e($movie['poster_url'] ?: 'https://via.placeholder.com/120x160?text=Movie') ?>" alt="">
                        </td>
                        <td><?= e($movie['title']) ?></td>
                        <td><?= e($movie['genres'] ?: 'Chưa gắn thể loại') ?></td>
                        <td><?= e($movie['language']) ?></td>
                        <td><?= (int) $movie['duration_min'] ?> phút</td>
                        <td><?= e($movie['age_rating'] ?: 'N/A') ?></td>
                        <td><?= !empty($movie['release_date']) ? date('d/m/Y', strtotime($movie['release_date'])) : 'N/A' ?></td>
                        <td>
                            <span class="admin-badge <?= $badgeClass ?>">
                                <?= e($movie['status']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="admin-actions">
                                <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/movies/edit.php?id=<?= (int) $movie['movie_id'] ?>">Sửa</a>
                                <a class="admin-btn-danger" href="<?= BASE_URL ?>admin/movies/delete.php?id=<?= (int) $movie['movie_id'] ?>" onclick="return confirm('Xóa phim này?')">Xóa</a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9"><div class="admin-empty">Không tìm thấy phim phù hợp.</div></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
if ($stmt) {
    $stmt->close();
}
require_once __DIR__ . '/../../includes/admin_layout_end.php';
?>