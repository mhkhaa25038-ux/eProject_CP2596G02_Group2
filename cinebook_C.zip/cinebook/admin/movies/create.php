<?php
$pageTitle = 'Thêm phim';
require_once __DIR__ . '/../../includes/admin_layout_start.php';

$conn = db_connect();
$error = '';

$genresResult = $conn->query("SELECT genre_id, name FROM genres ORDER BY name ASC");

$title = '';
$synopsis = '';
$language = '';
$durationMin = '';
$trailerUrl = '';
$posterUrl = '';
$status = 'coming_soon';
$ageRating = '';
$releaseDate = '';
$selectedGenres = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim(post('title'));
    $synopsis = trim(post('synopsis'));
    $language = trim(post('language'));
    $durationMin = (int) post('duration_min');
    $trailerUrl = trim(post('trailer_url'));
    $posterUrl = trim(post('poster_url'));
    $status = trim(post('status'));
    $ageRating = trim(post('age_rating'));
    $releaseDate = trim(post('release_date'));

    $selectedGenres = post('genres', []);
    if (!is_array($selectedGenres)) {
        $selectedGenres = [];
    }
    $selectedGenres = array_map('intval', $selectedGenres);
    $selectedGenres = array_unique(array_filter($selectedGenres));

    if ($title === '' || $language === '' || $durationMin <= 0) {
        $error = 'Vui lòng nhập đầy đủ tên phim, ngôn ngữ và thời lượng.';
    } elseif (empty($selectedGenres)) {
        $error = 'Mỗi phim phải có ít nhất một thể loại.';
    } else {
        $synopsis = $synopsis !== '' ? $synopsis : null;
        $trailerUrl = $trailerUrl !== '' ? $trailerUrl : null;
        $posterUrl = $posterUrl !== '' ? $posterUrl : null;
        $ageRating = $ageRating !== '' ? $ageRating : null;
        $releaseDate = $releaseDate !== '' ? $releaseDate : null;
        $status = $status !== '' ? $status : 'coming_soon';

        $sql = "
            INSERT INTO movies (
                title, synopsis, language, duration_min, trailer_url,
                poster_url, status, age_rating, release_date
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ";

        try {
            $conn->begin_transaction();

            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                throw new Exception('Lỗi prepare: ' . $conn->error);
            }

            $stmt->bind_param(
                'sssisssss',
                $title,
                $synopsis,
                $language,
                $durationMin,
                $trailerUrl,
                $posterUrl,
                $status,
                $ageRating,
                $releaseDate
            );

            if (!$stmt->execute()) {
                throw new Exception('Lỗi thêm phim: ' . $stmt->error);
            }

            $movieId = (int) $stmt->insert_id;
            $stmt->close();

            $genreStmt = $conn->prepare("INSERT INTO movie_genres (movie_id, genre_id) VALUES (?, ?)");

            if (!$genreStmt) {
                throw new Exception('Không thể chuẩn bị câu lệnh lưu thể loại.');
            }

            foreach ($selectedGenres as $genreId) {
                $genreStmt->bind_param('ii', $movieId, $genreId);

                if (!$genreStmt->execute()) {
                    throw new Exception('Không thể lưu thể loại cho phim.');
                }
            }

            $genreStmt->close();

            $conn->commit();
            set_flash_message('success', 'Thêm phim thành công.');
            redirect('admin/movies/index.php');
        } catch (Throwable $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    }
}
?>

<div class="admin-card">
    <div class="admin-card-head">
        <h2>Form thêm phim</h2>
        <a class="admin-btn-outline" href="<?= BASE_URL ?>admin/movies/index.php">Quay lại</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="admin-flash"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="admin-form-grid">
            <div class="admin-form-group">
                <label class="admin-label">Tên phim</label>
                <input class="admin-input" type="text" name="title" value="<?= e($title) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Ngôn ngữ</label>
                <input class="admin-input" type="text" name="language" value="<?= e($language) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Thời lượng (phút)</label>
                <input class="admin-input" type="number" name="duration_min" min="1" value="<?= e((string) $durationMin) ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Độ tuổi</label>
                <input class="admin-input" type="text" name="age_rating" value="<?= e($ageRating) ?>" placeholder="P, C13, C16...">
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Trạng thái</label>
                <select class="admin-select" name="status">
                    <option value="coming_soon" <?= $status === 'coming_soon' ? 'selected' : '' ?>>coming_soon</option>
                    <option value="now_showing" <?= $status === 'now_showing' ? 'selected' : '' ?>>now_showing</option>
                    <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>inactive</option>
                </select>
            </div>

            <div class="admin-form-group">
                <label class="admin-label">Ngày khởi chiếu</label>
                <input class="admin-input" type="date" name="release_date" value="<?= e($releaseDate) ?>">
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Thể loại <span style="color:#fca5a5;">*</span></label>

                <div style="display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:10px;">
                    <?php if ($genresResult && $genresResult->num_rows > 0): ?>
                        <?php while ($genre = $genresResult->fetch_assoc()): ?>
                            <label style="display:flex; align-items:center; gap:8px; background:#0f172a; padding:10px 12px; border:1px solid rgba(148,163,184,0.2); border-radius:10px;">
                                <input
                                    type="checkbox"
                                    name="genres[]"
                                    value="<?= (int) $genre['genre_id'] ?>"
                                    <?= in_array((int) $genre['genre_id'], $selectedGenres, true) ? 'checked' : '' ?>
                                >
                                <span><?= e($genre['name']) ?></span>
                            </label>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div style="color:#94a3b8;">Chưa có thể loại nào. Hãy tạo ở Manage Genres trước.</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Poster URL</label>
                <input class="admin-input" type="text" name="poster_url" value="<?= e($posterUrl) ?>">
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Trailer URL</label>
                <input class="admin-input" type="text" name="trailer_url" value="<?= e($trailerUrl) ?>">
            </div>

            <div class="admin-form-group full">
                <label class="admin-label">Mô tả</label>
                <textarea class="admin-textarea" name="synopsis"><?= e($synopsis) ?></textarea>
            </div>
        </div>

        <button class="admin-btn" type="submit">Lưu phim</button>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/admin_layout_end.php'; ?>