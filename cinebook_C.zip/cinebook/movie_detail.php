<?php
    require_once __DIR__ . '/includes/helpers.php';

    $conn    = db_connect();
    $movieId = (int) get('id');

    if ($movieId <= 0) {
    set_flash_message('error', 'Phim không hợp lệ.');
    redirect('movies.php');
    }

    $movieSql = "
    SELECT
        m.movie_id,
        m.title,
        m.synopsis,
        m.language,
        m.duration_min,
        m.trailer_url,
        m.poster_url,
        m.status,
        m.age_rating,
        m.release_date,
        m.created_at,
        GROUP_CONCAT(DISTINCT g.name ORDER BY g.name SEPARATOR ', ') AS genres
    FROM movies m
    LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
    LEFT JOIN genres g ON mg.genre_id = g.genre_id
    WHERE m.movie_id = ?
    GROUP BY
        m.movie_id,
        m.title,
        m.synopsis,
        m.language,
        m.duration_min,
        m.trailer_url,
        m.poster_url,
        m.status,
        m.age_rating,
        m.release_date,
        m.created_at
    LIMIT 1
";

    $movieStmt = $conn->prepare($movieSql);
    $movieStmt->bind_param('i', $movieId);
    $movieStmt->execute();
    $movieResult = $movieStmt->get_result();
    $movie       = $movieResult->fetch_assoc();
    $movieStmt->close();

    if (! $movie) {
    set_flash_message('error', 'Không tìm thấy phim.');
    redirect('movies.php');
    }

    $showtimeSql = "
    SELECT
        s.show_id,
        s.start_at,
        s.end_at,
        s.base_price,
        s.screen_format,
        s.subtitle_type,
        s.status,
        r.room_name,
        l.name AS location_name
    FROM showtimes s
    INNER JOIN rooms r ON s.room_id = r.room_id
    INNER JOIN locations l ON r.location_id = l.location_id
    WHERE s.movie_id = ?
      AND s.status = 'scheduled'
    ORDER BY s.start_at ASC
";

    $showtimeStmt = $conn->prepare($showtimeSql);
    $showtimeStmt->bind_param('i', $movieId);
    $showtimeStmt->execute();
    $showtimesResult = $showtimeStmt->get_result();

    require_once __DIR__ . '/includes/header.php';
?>

<section class="movie-detail-page">
    <div class="movie-detail-shell">
        <div class="movie-detail-main">
            <div class="movie-detail-poster">
                <img
                    src="<?php echo e($movie['poster_url'] ?: 'https://via.placeholder.com/500x750?text=Movie') ?>"
                    alt="<?php echo e($movie['title']) ?>"
                >
            </div>

            <div class="movie-detail-info">
                <div class="movie-detail-topline">
                    <span class="movie-status-badge <?php echo $movie['status'] === 'coming_soon' ? 'coming' : 'showing' ?>">
                        <?php echo $movie['status'] === 'coming_soon' ? 'COMING SOON' : 'NOW SHOWING' ?>
                    </span>
                </div>

                <h1 class="movie-detail-title"><?php echo e($movie['title']) ?></h1>

                <div class="movie-detail-info-lines">
                    <p><strong>Thể loại:</strong> <?php echo e($movie['genres'] ?: 'Đang cập nhật') ?></p>
                    <p><strong>Thời lượng:</strong> <?php echo (int) $movie['duration_min'] ?> phút</p>
                    <p><strong>Ngôn ngữ:</strong> <?php echo e($movie['language'] ?: 'Đang cập nhật') ?></p>
                    <p><strong>Độ tuổi:</strong> <?php echo e($movie['age_rating'] ?: 'Đang cập nhật') ?></p>
                    <p><strong>Khởi chiếu:</strong> <?php echo ! empty($movie['release_date']) ? date('d-m-Y', strtotime($movie['release_date'])) : 'Đang cập nhật' ?></p>


                </div>
                  <div class="movie-detail-actions">
                    <a class="movie-book-btn-dark" href="#showtimes">Book Now</a>
                    <a class="movie-detail-outline-btn" href="<?php echo BASE_URL ?>movies.php">Back to Movies</a>
                </div> <br>

<div class="movie-detail-box">
    <button type="button" class="detail-toggle-btn">
        Chi tiết
    </button>

    <div class="movie-detail-desc">
        <p class="detail-label">Chi tiết:</p>
        <p><?php echo e($movie['synopsis'] ?: 'Chưa có mô tả nội dung phim.') ?></p>
    </div>
</div>

                <div class="movie-detail-extra">
                    <div class="movie-detail-extra-item">
                        <span>Trailer</span>
                        <?php if (! empty($movie['trailer_url'])): ?>
                            <a href="<?php echo e($movie['trailer_url']) ?>" target="_blank">Watch trailer</a>
                        <?php else: ?>
                            <strong>Updating</strong>
                        <?php endif; ?>
                    </div>
                </div>


            </div>
        </div>

        <div class="movie-detail-block" id="showtimes">
            <div class="movie-detail-block-head">
                <h2>Showtimes</h2>
            </div>

            <?php if ($showtimesResult && $showtimesResult->num_rows > 0): ?>
                <div class="showtime-grid-dark">
                    <?php while ($show = $showtimesResult->fetch_assoc()): ?>
                        <a class="showtime-card-dark" href="<?php echo BASE_URL ?>select_seats.php?show_id=<?php echo (int) $show['show_id'] ?>">
                            <div class="showtime-card-time">
                                <?php echo date('d/m H:i', strtotime($show['start_at'])) ?>
                            </div>
                            <div class="showtime-card-location">
                                <?php echo e($show['location_name']) ?> - <?php echo e($show['room_name']) ?>
                            </div>
                            <div class="showtime-card-meta">
                                <?php echo e($show['screen_format'] ?: '2D') ?>
                                <?php echo ! empty($show['subtitle_type']) ? ' • ' . e($show['subtitle_type']) : '' ?>
                            </div>
                            <div class="showtime-card-price">
                                <?php echo format_currency($show['base_price']) ?>
                            </div>
                        </a>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">Hiện chưa có suất chiếu cho phim này.</div>
            <?php endif; ?>
        </div>
    </div>
</section>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const toggleButtons = document.querySelectorAll('.detail-toggle-btn');

    toggleButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const detailBox = button.nextElementSibling;

            if (detailBox) {
                detailBox.classList.toggle('show');

                button.textContent = detailBox.classList.contains('show')
                    ? 'Ẩn chi tiết'
                    : 'Chi tiết';
            }
        });
    });
});
</script>

<?php
    $showtimeStmt->close();
require_once __DIR__ . '/includes/footer.php';
?>