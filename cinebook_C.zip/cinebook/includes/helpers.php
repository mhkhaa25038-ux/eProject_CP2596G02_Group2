<?php
require_once __DIR__ . '/../config/database.php';

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path = ''): void
{
    $path = ltrim($path, '/');
    header('Location: ' . BASE_URL . $path);
    exit;
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

function is_admin(): bool
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function get_current_user_data(): ?array
{
    if (!is_logged_in()) {
        return null;
    }

    $conn = db_connect();
    $userId = (int) $_SESSION['user_id'];

    $sql = "SELECT * FROM users WHERE user_id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('i', $userId);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    $stmt->close();

    return $user ?: null;
}

function format_currency($amount): string
{
    return number_format((float)$amount, 0, ',', '.') . ' đ';
}

function generate_booking_code(): string
{
    return 'BK' . date('YmdHis') . rand(100, 999);
}

function set_flash_message(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function get_flash_message(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    return $flash;
}

function old(string $key, $default = '')
{
    $value = $_POST[$key] ?? $default;

    if (is_string($value)) {
        return trim($value);
    }

    return $value;
}

function post(string $key, $default = '')
{
    $value = $_POST[$key] ?? $default;

    if (is_string($value)) {
        return trim($value);
    }

    return $value;
}

function get(string $key, $default = '')
{
    $value = $_GET[$key] ?? $default;

    if (is_string($value)) {
        return trim($value);
    }

    return $value;
}

function count_showtime_bookings(mysqli $conn, int $showId): int
{
    $sql = "SELECT COUNT(*) AS total FROM bookings WHERE show_id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return 0;
    }

    $stmt->bind_param('i', $showId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return (int) ($row['total'] ?? 0);
}

function sync_show_seats(mysqli $conn, int $showId, int $roomId, float $basePrice, bool $resetAll = false): bool
{
    if ($resetAll) {
        $deleteStmt = $conn->prepare("DELETE FROM show_seats WHERE show_id = ?");

        if (!$deleteStmt) {
            return false;
        }

        $deleteStmt->bind_param('i', $showId);

        if (!$deleteStmt->execute()) {
            $deleteStmt->close();
            return false;
        }

        $deleteStmt->close();
    } else {
        $deleteOrphanSql = "
            DELETE ss
            FROM show_seats ss
            LEFT JOIN booking_seats bs ON ss.show_seat_id = bs.show_seat_id
            LEFT JOIN seats se ON ss.seat_id = se.seat_id
            WHERE ss.show_id = ?
              AND bs.booking_seat_id IS NULL
              AND (se.seat_id IS NULL OR se.room_id <> ?)
        ";
        $deleteOrphanStmt = $conn->prepare($deleteOrphanSql);

        if ($deleteOrphanStmt) {
            $deleteOrphanStmt->bind_param('ii', $showId, $roomId);
            $deleteOrphanStmt->execute();
            $deleteOrphanStmt->close();
        }
    }

    $updateSql = "
        UPDATE show_seats ss
        INNER JOIN seats se ON ss.seat_id = se.seat_id
        INNER JOIN seat_categories sc ON se.category_id = sc.category_id
        SET ss.final_price = ROUND(? * sc.price_multiplier, 2)
        WHERE ss.show_id = ?
          AND se.room_id = ?
    ";
    $updateStmt = $conn->prepare($updateSql);

    if (!$updateStmt) {
        return false;
    }

    $updateStmt->bind_param('dii', $basePrice, $showId, $roomId);

    if (!$updateStmt->execute()) {
        $updateStmt->close();
        return false;
    }

    $updateStmt->close();

    $insertSql = "
        INSERT INTO show_seats (show_id, seat_id, status, hold_until, hold_token, final_price)
        SELECT
            ?,
            se.seat_id,
            'available',
            NULL,
            NULL,
            ROUND(? * sc.price_multiplier, 2)
        FROM seats se
        INNER JOIN seat_categories sc ON se.category_id = sc.category_id
        LEFT JOIN show_seats ss ON ss.show_id = ? AND ss.seat_id = se.seat_id
        WHERE se.room_id = ?
          AND ss.show_seat_id IS NULL
    ";
    $insertStmt = $conn->prepare($insertSql);

    if (!$insertStmt) {
        return false;
    }

    $insertStmt->bind_param('idii', $showId, $basePrice, $showId, $roomId);
    $success = $insertStmt->execute();
    $insertStmt->close();

    return $success;
}