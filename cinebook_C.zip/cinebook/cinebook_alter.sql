CREATE DATABASE cinebook CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cinebook;

-- USERS
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  preferred_language VARCHAR(20) DEFAULT 'vi',
  status VARCHAR(20) DEFAULT 'active',
  role VARCHAR(20) DEFAULT 'user',
  loyalty_points INT DEFAULT 0,
  member_tier VARCHAR(50) DEFAULT 'Standard',
  email_verified TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- GENRES
CREATE TABLE genres (
  genre_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL
);

-- MOVIES
CREATE TABLE movies (
  movie_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  synopsis TEXT,
  language VARCHAR(50),
  duration_min INT,
  trailer_url VARCHAR(255),
  poster_url VARCHAR(255),
  status VARCHAR(20) DEFAULT 'coming_soon',
  age_rating VARCHAR(10),
  release_date DATE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- MOVIE GENRES
CREATE TABLE movie_genres (
  movie_id INT,
  genre_id INT,
  PRIMARY KEY (movie_id, genre_id),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
  FOREIGN KEY (genre_id) REFERENCES genres(genre_id) ON DELETE CASCADE
);

-- LOCATIONS
CREATE TABLE locations (
  location_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  address VARCHAR(255),
  city VARCHAR(100),
  phone VARCHAR(20),
  status VARCHAR(20) DEFAULT 'active'
);

-- ROOMS
CREATE TABLE rooms (
  room_id INT AUTO_INCREMENT PRIMARY KEY,
  location_id INT,
  room_name VARCHAR(50),
  capacity INT,
  status VARCHAR(20) DEFAULT 'active',
  FOREIGN KEY (location_id) REFERENCES locations(location_id) ON DELETE CASCADE
);

-- SEAT CATEGORY
CREATE TABLE seat_categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) UNIQUE,
  price_multiplier DECIMAL(5,2) DEFAULT 1.00
);

-- SEATS
CREATE TABLE seats (
  seat_id INT AUTO_INCREMENT PRIMARY KEY,
  room_id INT,
  category_id INT,
  seat_number VARCHAR(10),
  seat_row VARCHAR(10),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES seat_categories(category_id)
);

-- SHOWTIMES
CREATE TABLE showtimes (
  show_id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT,
  room_id INT,
  start_at DATETIME,
  end_at DATETIME,
  base_price DECIMAL(10,2),
  screen_format VARCHAR(50) DEFAULT '2D',
  status VARCHAR(20) DEFAULT 'scheduled',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
  FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
);

-- SHOW SEATS
CREATE TABLE show_seats (
  show_seat_id INT AUTO_INCREMENT PRIMARY KEY,
  show_id INT,
  seat_id INT,
  status VARCHAR(20) DEFAULT 'available',
  final_price DECIMAL(10,2),
  UNIQUE (show_id, seat_id),
  FOREIGN KEY (show_id) REFERENCES showtimes(show_id) ON DELETE CASCADE,
  FOREIGN KEY (seat_id) REFERENCES seats(seat_id) ON DELETE CASCADE
);

-- BOOKINGS
CREATE TABLE bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  show_id INT,
  booking_code VARCHAR(50) UNIQUE,
  status VARCHAR(20) DEFAULT 'pending',
  total DECIMAL(10,2),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (show_id) REFERENCES showtimes(show_id) ON DELETE CASCADE
);

-- BOOKING SEATS
CREATE TABLE booking_seats (
  booking_seat_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT,
  show_seat_id INT,
  UNIQUE (booking_id, show_seat_id),
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
  FOREIGN KEY (show_seat_id) REFERENCES show_seats(show_seat_id) ON DELETE CASCADE
);

-- COMBO PRODUCTS
CREATE TABLE combo_products (
  combo_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  description TEXT,
  price DECIMAL(10,2),
  image VARCHAR(255),
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- BOOKING COMBOS
CREATE TABLE booking_combos (
  booking_combo_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT,
  combo_id INT,
  quantity INT DEFAULT 1,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
  FOREIGN KEY (combo_id) REFERENCES combo_products(combo_id)
);

-- PAYMENTS
CREATE TABLE payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT,
  method VARCHAR(50),
  amount DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'pending',
  paid_at DATETIME,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

-- EVENTS
CREATE TABLE events (
  event_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  description TEXT,
  start_at DATETIME,
  end_at DATETIME,
  image VARCHAR(255),
  status VARCHAR(20) DEFAULT 'active'
);

-- BANNERS
CREATE TABLE banners (
  banner_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  image_url VARCHAR(255),
  link_url VARCHAR(255),
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- AUDIT LOG
CREATE TABLE audit_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action VARCHAR(100),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

INSERT INTO `events` (`event_id`, `title`, `description`, `start_at`, `end_at`, `image`, `status`) VALUES
(1, 'GIẢM 200K KHI DẪN MẸ ĐI XEM “ĐẾM NGÀY XA MẸ” – GOLD CLASS', '...', '2026-03-19 07:37:00', '2026-03-20 07:37:00', 'https://iguov8nhvyobj.vcdn.cloud/media/wysiwyg/2026/032026/350-x-495.jpg', 'active'),
(2, 'THỬ THÁCH THÌ THẦM', '...', '2026-03-19 09:08:00', '2026-03-31 09:08:00', 'https://iguov8nhvyobj.vcdn.cloud/media/wysiwyg/2026/032026/N_O_350x495.png', 'active'),
(3, 'QUÀ ĐỘC QUYỀN VIP 2026...', '...', '2026-03-19 09:09:00', '2026-03-31 09:09:00', 'https://iguov8nhvyobj.vcdn.cloud/media/wysiwyg/2026/022026/350x495_32_.jpg', 'active'),
(4, 'QUÀ ĐỘC QUYỀN VIP 2026...', '...', '2026-03-19 09:10:00', '2026-03-31 09:10:00', 'https://iguov8nhvyobj.vcdn.cloud/media/wysiwyg/2026/022026/350x495_32_.jpg', 'active'),
(5, 'QUÀ TẶNG SINH NHẬT...', '...', '2026-03-19 09:50:00', '2026-03-31 09:50:00', 'https://iguov8nhvyobj.vcdn.cloud/media/wysiwyg/2026/022026/350x495_34_.jpg', 'active');

INSERT INTO `genres` (`genre_id`, `name`) VALUES
(1, 'Hành động');

INSERT INTO `movies` (`movie_id`, `title`, `synopsis`, `language`, `duration_min`, `trailer_url`, `poster_url`, `status`, `age_rating`, `release_date`, `created_at`, `updated_at`) VALUES
(1, 'Cô dâu', '...', 'vi', 120, 'https://youtu.be/HYIOdcSGON4', 'https://iguov8nhvyobj.vcdn.cloud/media/catalog/product/...jpg', 'now_showing', 'T18', '2026-03-19', '2026-03-19 07:49:23', '2026-03-19 08:25:38'),
(2, 'Qủy nhập tràng', '...', 'vi', 126, 'https://youtu.be/VCI9XTxlQxk', 'https://iguov8nhvyobj.vcdn.cloud/media/catalog/product/...jpg', 'now_showing', 'T18', '2026-03-19', '2026-03-19 08:09:57', '2026-03-19 08:09:57'),
(3, 'ĐẾM NGÀY XA MẸ', '...', 'vi', 120, 'https://youtu.be/Dp-3zxsfWbw', 'https://iguov8nhvyobj.vcdn.cloud/media/catalog/product/...jpg', 'now_showing', 'T12', '2026-03-19', '2026-03-19 08:11:58', '2026-03-19 08:11:58'),
(4, 'THOÁT KHỎI TẬN THẾ', '...', 'vi', 100, 'https://youtu.be/LQ9KHDpA9vI', 'https://iguov8nhvyobj.vcdn.cloud/media/catalog/product/...jpg', 'coming_soon', 'T15', '2026-03-19', '2026-03-19 08:13:30', '2026-03-19 08:35:18'),
(5, 'TÀI', '...', 'vi', 90, 'https://youtu.be/z8H4miEhi-4', 'https://iguov8nhvyobj.vcdn.cloud/media/catalog/product/...jpg', 'inactive', 'T18', '2026-03-19', '2026-03-19 08:14:52', '2026-03-19 08:41:31');

INSERT INTO `movie_genres` (`movie_id`, `genre_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1);

INSERT INTO `users` (`user_id`, `name`, `email`, `phone`, `password_hash`, `preferred_language`, `status`, `role`, `loyalty_points`, `member_tier`, `email_verified`, `created_at`, `updated_at`) VALUES
(1, 'Mai Hữu Kha', 'maihuukha180407@gmail.com', '0384729080', '$2y$10$.L8J9Ff13T6wJqT0cERZs.S/9DhdIe1X744JG4sZkM9NwKRJZK1iq', 'vi', 'active', 'admin', 0, 'Standard', 0, '2026-03-12 15:46:29', '2026-03-12 15:47:35'),
(2, 'Cũng Quang Long', 'ql@gamil.com', '123456789', '$2y$10$ZQYmk.fRM/ECOvREiKBXJu770pOHThrlmbpBmBhhiaU.v8iveBICG', 'vi', 'active', 'user', 0, 'Standard', 0, '2026-03-12 15:49:33', '2026-03-12 15:49:33'),

